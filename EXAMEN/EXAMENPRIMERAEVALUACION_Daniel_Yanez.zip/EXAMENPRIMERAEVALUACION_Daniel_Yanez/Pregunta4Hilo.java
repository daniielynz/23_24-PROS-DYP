package examen;

public class Pregunta4Hilo{

	static int variable = 0;
	static void anadir() {
		variable++;
		System.out.println("Variable: " + variable);
	}
	
}
